package Mirthon.Oasis_back.domain;

public enum FountainState {
    오염, 정상
}
