package Mirthon.Oasis_back.domain;

public enum FountainWaterState {
    단수,음수가능
}
