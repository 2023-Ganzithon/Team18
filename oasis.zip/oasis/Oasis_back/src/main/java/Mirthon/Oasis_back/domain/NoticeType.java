package Mirthon.Oasis_back.domain;

public enum NoticeType {
    단수, 수질부적합
}
