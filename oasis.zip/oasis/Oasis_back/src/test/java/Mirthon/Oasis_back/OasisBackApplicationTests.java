package Mirthon.Oasis_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.annotation.CrossOrigin;

@SpringBootTest
class OasisBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
