import { createBrowserRouter } from "react-router-dom";

import Main from "../pages/main/index";
import Shop from "../pages/shop";
import CoconutLog from "../pages/coconutLog";
import Alert from "../pages/alert";
import Login from "../pages/login";
import MyPage from "../pages/mypage";
import Volunteer from "../pages/volunteer";
import VolunteerDetail from "../pages/volunteerDetail";
import LoginRedirection from "../pages/loginRedirection";

const Router = createBrowserRouter([
  {
    path: "/",
    element: <Main />,
  },
  {
    path: "/shop",
    element: <Shop />,
  },
  {
    path: "/coconut-log",
    element: <CoconutLog />,
  },
  {
    path: "/alert",
    element: <Alert />,
  },
  {
    path: "/mypage",
    element: <MyPage />,
  },

  {
    path: "/volunteer",
    element: <Volunteer />,
  },
  {
    path: "/volunteer/:id",
    element: <VolunteerDetail />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/loginRedirection",
    element: <LoginRedirection />,
  },
]);

export default Router;
