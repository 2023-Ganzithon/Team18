import GlobalStyle from './styles/globalStyles';
import { ThemeProvider } from 'styled-components';
import { RouterProvider } from 'react-router-dom';
import { theme } from './styles/theme';
import { Suspense } from 'react';
import { RecoilRoot } from 'recoil';
import Router from './components/Router';
import Layout from './components/Layout';

export default function App() {
  return (
    <>
      <ThemeProvider theme={theme}>
        <RecoilRoot>
          <GlobalStyle />
          <Layout>
            <Suspense>
              <RouterProvider router={Router} />
            </Suspense>
          </Layout>
        </RecoilRoot>
      </ThemeProvider>
    </>
  );
}
