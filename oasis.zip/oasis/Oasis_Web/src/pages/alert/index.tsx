import React,{ useState,useEffect } from "react";
import styled from "styled-components";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { IconBanned,IconContaminated } from "../../assets/images/icons";

interface AlertAmountProps {
    noticeType: string;
  }
  interface Fountain {
    fountainId: number;
    fountainName: string;
    location_x: number;
    location_y: number;
    fountainAddress: string;
    foundtainDetail: string;
    fountainState: string;
    fountainWaterState: string;
    visited: boolean;
    visitedDate: string | null;
    userId: number;
  }
  
  interface AlertRecord {
    noticeId: number;
    noticeType: string;
    noticeContent: string;
    noticeDate: string;
    fountain: Fountain;
  }
  

const StyledIconBanned = styled(IconBanned)`
  width : 20px;
  height : 20px;
`;

const StyledIconContaminated = styled(IconContaminated)`
  width : 20px;
  height : 20px;
`;

const AlertDataContainer = styled.div`
  padding: 20px;
  margin-top: 100px;
`;

const AlertList = styled.ul`
  list-style: none;
  padding: 0;
`;

const AlertItem = styled.li`
  display: flex;
  justify-content: space-between;
  gap: 30px; /* 원하는 간격으로 조정 */
  margin-bottom: 20px;
  padding: 20px;
  padding-left: 40px;
  padding-right: 40px;
  border: 1px solid #ddd;
  border-radius: 4px;
`;


const AlertDate = styled.span`
  font-weight: bold;
  color: #666;
  font-size: 1.4rem;
`;

const AlertLocation = styled.span`
  color: #666;
  font-size: 1.4rem;
`;

const AlertAmount = styled.span<AlertAmountProps>`
  display: flex;
  align-items: center;
  color: ${(props) => (props.noticeType === '단수' ? 'red' : 'green')};
  font-size: 1.4rem;

  svg {
    margin-right: 8px;
  }
`;


const AlertLogContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
`;


const Alert: React.FC = () => {
    const [alertData, setAlertData] = useState<AlertRecord[]>([]);
    const fountainId = 6
  
    useEffect(() => {
      const fetchData = async () => {
        try {
          const response = await fetch(`http://49.50.160.62:8080/api/getAllNotice/${fountainId}`);
          const data: AlertRecord[] = await response.json();
          setAlertData(data);
        } catch (error) {
          console.error("데이터 로딩 중 오류 발생:", error);
        }
      };
  
      fetchData();
    }, [fountainId]);
  
    return (
        <AlertLogContainer>
          <Header />
          <AlertDataContainer>
            <h2>경보 내역</h2>
            <AlertList>
              {alertData.map((record, index) => (
                <AlertItem key={index}>
                  <AlertDate>{record.noticeDate.substring(0, 10)}</AlertDate>
                  <AlertLocation>{record.fountain.fountainName}</AlertLocation>
                  <AlertAmount noticeType={record.noticeType}>
                    {record.noticeType === '단수' && <StyledIconBanned />}
                    {record.noticeType === '수질부적합' && <StyledIconContaminated />}
                    {record.noticeType}
                  </AlertAmount>
                </AlertItem>
              ))}
            </AlertList>
          </AlertDataContainer>
          <Footer />
        </AlertLogContainer>
      );
    };
    
    export default Alert;