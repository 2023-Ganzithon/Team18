import React from "react";
import styled from "styled-components";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { useParams } from "react-router-dom";
import { LogoHeader } from "../../assets/images/logo";
import { useNavigate } from "react-router-dom";
interface Selected {
  title: string;
  p: string;
  url: string;
}

export default function VolunteerDetail() {
  const navigate = useNavigate();
  const Container = styled.div`
    display: flex;
    margin: 0 auto;
    justify-content: center;
    flex-direction: column;
  `;
  const SectionMini = styled.div`
    color: black;
    font-size: 1.6rem;
    border: 2px;
  `;
  const DetailedMini = styled.div`
    color: black;
    font-size: 1.4rem;
    padding: 10px;
    border: solid #85b6ff;
    border-radius: 15px;
  `;

  const Section = styled.div`
    display: flex;
    justify-content: space-around;
    align-items: center;
    margin-top: 79px;
    height: 70px;
    box-shadow: 0 2px 0 0 #85b6ff;
  `;
  const Detailed = styled.div`
    display: flex;
    justify-content: center;
    flex-direction: column;
    .Img {
      display: flex;
      justify-content: center;
      padding: 15px;
      border: solid #85b6ff;
      border-radius: 15px;
      margin-top: 1px;
    }
    .pClass {
      padding: 10px;

      button {
        margin-top: 15px;
        position: relative;
        border: none;
        width: 100%;

        padding: 10px 20px;
        border-radius: 15px;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        text-decoration: none;
        font-weight: 500;
        transition: 0.25s;
        background-color: #85b6ff;
      }
      button a {
        text-decoration: none;
        font-size: 20px;
        color: white;
      }
      .btnDiv {
        display: flex;
        justify-content: center;
        flex-direction: column;
      }
    }
  `;
  const dummyData = [
    {
      title: "청소년 자원봉사의 날 - 효곡동 그린단지 환경정화활동",
      p: "* 포항시 관내 청소년(14~19세)만 신청 가능 * 날씨 및 기관 사정에 따라 활동이 취소될 수 있습니다.* 포항시 관내 청소년(14~19세)만 신청 가능 * 날씨 및 기관 사정에 따라 활동이 취소될 수 있습니다.* 포항시 관내 청소년(14~19세)만 신청 가능 * 날씨 및 기관 사정에 따라 활동이 취소될 수 있습니다.* 포항시 관내 청소년(14~19세)만 신청 가능 * 날씨 및 기관 사정에 따라 활동이 취소될 수 있습니다.",
      url: "https://www.naver.com/",
    },
    {
      title: "청소년 자원봉사의 날 - 효곡동 그린단지 환경정화활동",
      p: "* 포항시 관내 청소년(14~19세)만 신청 가능 * 날씨 및 기관 사정에 따라 활동이 취소될 수 있습니다.",
      url: "https://www.naver.com/",
    },

    {
      title: "핫플 성수 플로깅 함께 해요",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "청소년 자원봉사의 날 - 효곡동 그린단지 환경정화활동",
      p: "* 포항시 관내 청소년(14~19세)만 신청 가능 * 날씨 및 기관 사정에 따라 활동이 취소될 수 있습니다.",
      url: "https://www.naver.com/",
    },
    {
      title: "청소년 자원봉사의 날 - 효곡동 그린단지 환경정화활동",
      p: "* 포항시 관내 청소년(14~19세)만 신청 가능 * 날씨 및 기관 사정에 따라 활동이 취소될 수 있습니다.",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "청소년 자원봉사의 날 - 효곡동 그린단지 환경정화활동",
      p: "* 포항시 관내 청소년(14~19세)만 신청 가능 * 날씨 및 기관 사정에 따라 활동이 취소될 수 있습니다.",
      url: "https://www.naver.com/",
    },
    {
      title: "청소년 자원봉사의 날 - 효곡동 그린단지 환경정화활동",
      p: "* 포항시 관내 청소년(14~19세)만 신청 가능 * 날씨 및 기관 사정에 따라 활동이 취소될 수 있습니다.",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
  ];

  return (
    <Container>
      <Header />
      <Section>
        <SectionMini>{dummyData[0].title}</SectionMini>
      </Section>
      <Detailed>
        <div className="Img">
          <LogoHeader width="100%" height="200" />
        </div>
        <div className="pClass">
          <DetailedMini>{dummyData[0].p}</DetailedMini>
          <div className="btnDiv">
            <button>
              <a
                href={dummyData[0].url}
                target="_blank"
                rel="noopener noreferrer"
              >
                바로가기
              </a>
            </button>
            <button onClick={() => navigate(-1)}>
              <a>뒤로가기</a>
            </button>
          </div>
        </div>
      </Detailed>
      <Footer />
    </Container>
  );
}
