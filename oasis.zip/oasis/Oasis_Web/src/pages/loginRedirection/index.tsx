import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import axios from "axios";


//인가코드 백으로 보내는 코드
const LoginRedirection = () => {
    const navigate = useNavigate();
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    console.log(code)
  
    useEffect(() => {
      if (code) {
        axios.get(`http://localhost:8080/auth/kakao/callback/?code=${code}`)
          .then((res) => {
            // 로그인 성공 후 처리
            console.log(res);
            localStorage.setItem("name", res.data.account.kakaoName);
            navigate("/");
          })
          .catch(error => {
            console.error('Login failed:', error);
            navigate('/login');
          });
      }
    }, [code, navigate]);

  return (
    <div className="LoginHandeler">
      <div className="notice">
        <p>로그인 중입니다.</p>
        <p>잠시만 기다려주세요.</p>
        <div className="spinner"></div>
      </div>
    </div>
  );
};

export default LoginRedirection;