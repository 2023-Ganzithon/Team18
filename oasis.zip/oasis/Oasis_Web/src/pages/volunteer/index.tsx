import React, { useEffect } from "react";
import styled, { keyframes } from "styled-components";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { useState } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import { theme } from "../../styles/theme";
import { LogoHeader } from "../../assets/images/logo";
import { getVol } from "../../utils/api/axios";
import { getWaterVol } from "../../utils/api/axios";
export default function Volunteer() {
  const [selected, setSelected] = useState<string>("protected");
  const { id } = useParams();
  const [volData, setVolData] = useState([]);
  const [waterVolData, setWaterVolData] = useState([]);
  const [loading, setLoading] = useState(true); // 로딩 상태 추가
  const handleLocationClick = (selected: React.SetStateAction<string>) => {
    setSelected(selected);
  };
  const Container = styled.div`
    display: flex;
    margin: 0 auto;
    justify-content: center;
    flex-direction: column;
    font-family: "PretendardBold", sans-serif;
    font-style: normal;
    font-weight: 700;
    font-size: 2.4rem;
    line-height: 2.9rem;
    background-color: #ffa539;
  `;
  const SectionMini = styled.div`
    color: black;
    font-size: 1.6rem;
    color: white;
    border-radius: 10px;
    padding: 10px;
  `;
  const ContentMini = styled.div`
    color: black;
    font-size: 3.5rem;

    h1 {
      color: black;
      font-size: 17px;
    }
    p {
      margin-top: 7px;
    }
    .firstDiv {
      margin-top: 0px;
    }
    .lastDiv {
      margin-bottom: 85px;
    }
    .pDiv {
      border-radius: 10px;
      border: 0.1rem solid #ffa539;
      padding: 10px;
    }
    div {
      padding: 10px;
      border-radius: 10px;
      border: 0.1rem solid #ffa539;
      margin-top: 12px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      background-color: white;
    }
    a {
      font-size: 20px;
      text-decoration: none;
      p {
        font-size: 13px;
        text-decoration: none;
        color: black;
      }
    }
    .imgDiv {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: row;
    }
    .titleAndDate {
      display: flex;
      flex-direction: column;
      border: none;
      box-shadow: none;
    }
    .imgUrl {
      width: 150px;
      height: 150px;
      border-radius: 15px;
    }
  `;

  const Section = styled.div`
    display: flex;
    justify-content: space-around;
    align-items: center;
    margin-top: 79px;
    height: 60px;

    background-color: #ffa539;
  `;
  const Content = styled.div`
    display: flex;
    justify-content: center;
  `;
  const dummyData = [
    {
      title: "핫플 성수 플로깅 함께 해요",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00  장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00  장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "핫플 성수 플로깅 함께 해요",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00  장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
  ];

  const dummyData2 = [
    {
      title: "호호 됐나요?",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "호호 됐나요?",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "호호 됐나요?",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "호호 됐나요?",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "호호 됐나요?",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
    {
      title: "호호 됐나요?",
      date: "2023.11.11",
      member: "13",
      center: "봉사기관",
      p: " 일시: 2023.11.11.(토) 10:00 ~ 12:00 장소: 성수동 구두테마공원(연무장5길 9-26) 문의: 성동구자원봉사센터 02-499-5056 * 참가자 전원 플로깅 키트 및 럭키박스 제공",
      url: "https://www.naver.com/",
    },
  ];

  const fetchData2 = async () => {
    try {
      const data = await getWaterVol();
      console.log(data);
      setWaterVolData(data);
    } catch (error) {
      console.error("데이터를 가져오는 중 에러 발생:", error);
    }
  };
  fetchData2();
  const content = (
    <ContentMini>
      {selected === "watched"
        ? volData.map((value, index) => (
            <Link to={`/volunteer/${index + 1}`} key={index}>
              <div
                className={`content-item ${index === 0 ? "firstDiv" : ""} ${
                  index === volData.length - 1 ? "lastDiv" : ""
                }`}
              >
                <div className="imgDiv">
                  <img className="valueImg" src={value.imgUrl}></img>
                  <div className="titleAndDate">
                    <h1>{value.title}</h1>
                    <p>{value.date}</p>
                    <p>인원수 : {value.member}</p>
                  </div>
                </div>

                <p className="pDiv">{value.p}</p>
                <p>봉사기관 : {value.center}</p>
              </div>
            </Link>
          ))
        : selected === "protected"
        ? waterVolData.map((value, index) => (
            <Link to={`/volunteer/${index + 1}`} key={index}>
              <div
                className={`content-item ${index === 0 ? "firstDiv" : ""} ${
                  index === waterVolData.length - 1 ? "lastDiv" : ""
                }`}
              >
                <div className="imgDiv">
                  <img className="imgUrl" src={value.imgUrl}></img>
                  <div className="titleAndDate">
                    <h1>{value.title}</h1>
                    <p>{value.date}</p>
                    <p>인원수 : {value.member}</p>
                  </div>
                </div>

                <p className="pDiv">{value.p}</p>
                <p>봉사기관 : {value.center}</p>
              </div>
            </Link>
          ))
        : null}
    </ContentMini>
  );
  return (
    <Container>
      <Header />
      <Section>
        <SectionMini
          onClick={() => handleLocationClick("protected")}
          className="protect"
        >
          수질
        </SectionMini>
      </Section>
      <Content>{content}</Content>
      <Footer />
    </Container>
  );
}
