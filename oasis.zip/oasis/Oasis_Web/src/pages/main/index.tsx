import styled from "styled-components";
import useKakaoLoader from "./useKakaoLoader.js";
import { Map } from "react-kakao-maps-sdk";
import { MapMarker } from "react-kakao-maps-sdk";
import { MarkerClusterer } from "react-kakao-maps-sdk";
import location from "./location.js";
import Header from "../../components/Header.js";
import Footer from "../../components/Footer.js";
import IcWaterOff from "../../assets/images/icons/IcWaterOff.svg";
import IcCamel from "../../assets/images/icons/IcCamel.svg";
import IcContaminated from "../../assets/images/icons/IcContaminated.svg";
import IcBanned from "../../assets/images/icons/IcBanned.svg";
import { useState, useEffect } from "react";
import { getWater } from "../../utils/api/axios.ts";
import Modal from "../../components/Modal.tsx";
import changeLocation from "./changeLocation.tsx";
import waterData from "../../utils/data/water.ts";
type LocationType = {
  latitude: number;
  longitude: number;
};

interface Marker {
  cot_conts_name?: string;
  cot_conts_id?: string;
  title: string;
}

export default function Main() {
  const [serverData, setServerData] = useState(null);
  const [clicked, isClicked] = useState(false);
  const [positionGet, setPositionGet] = useState();
  const [selectedMarker, setSelectedMarker] = useState([]);
  const [loading, setLoading] = useState(true); // 로딩 상태 추가
  const locationGet = location(); // 내 위치
  const { latitude, longitude } = locationGet as LocationType;
  const [goState, setGoState] = useState(false);
  changeLocation();

  const fetchData = async () => {
    try {
      const data = await getWater();
      console.log(data);
      setServerData(data);
      setLoading(false); // 데이터가 로드되면 로딩 상태 변경
    } catch (error) {
      console.error("데이터를 가져오는 중 에러 발생:", error);
      setLoading(false); // 에러가 발생해도 로딩 상태 변경
    }
  };

  fetchData(); // 함수 호출

  const postPoint = async () => {
    try {
      const data = await point();
      console.log(data);
    } catch (error) {
      console.error("데이터를 가져오는 중 에러 발생:", error);
    }
  };
  postPoint();
  useEffect(() => {
    const calculateDistanceAndFilter = () => {
      if (!loading && serverData) {
        const nearby = serverData.filter((position) => {
          const dLat = latitude - position.lat;
          const dLon = longitude - position.lng;

          if (dLat <= 1 && dLon <= 1) {
            setGoState(true); // goState가 true면 모달에 아이콘 표시
            return true; //
          }
          return false;
        });
      }
    };

    calculateDistanceAndFilter();
  }, [loading, serverData, latitude, longitude]);

  const closeModal = () => {
    isClicked(false);
  };

  const openModal = () => {
    isClicked(true);
  };

  const handleMarkerClick = (position) => {
    setSelectedMarker(position);
    openModal();
  };

  useKakaoLoader();

  const Container = styled.div`
    display: flex;
    margin: 0 auto;
    justify-content: center;
    flex-direction: column;
  `;

  return (
    <Container>
      <Header />
      {loading ? (
        // 데이터 로딩 중일 때 표시할 화면
        <p>Loading...</p>
      ) : serverData ? (
        <Map
          center={{ lat: latitude, lng: longitude }}
          style={{ width: "100%", height: "794px", marginTop: "79px" }}
          level={4}
        >
          <MarkerClusterer
            averageCenter={true} // 클러스터에 포함된 마커들의 평균 위치를 클러스터 마커 위치로 설정
            minLevel={7} // 클러스터 할 최소 지도 레벨
          >
            {waterData.DATA.map((position) => (
              <MapMarker
                onClick={(_t, mouseEvent) =>
                  setPositionGet({
                    lat: mouseEvent.latLng.getLat(),
                    lng: mouseEvent.latLng.getLng(),
                  })
                }
                position={{
                  //lat: position.location_x,
                  lat: position.lat,
                  //lng: position.location_y,
                  lng: position.lng,
                }}
                image={{
                  src:
                    position.status === "정상"
                      ? IcContaminated
                      : position.status === "음수가능"
                      ? IcBanned
                      : IcWaterOff,

                  size: {
                    width: 24,
                    height: 35,
                  }, // 마커이미지의 크기입니다
                }}
                title={position.cot_conts_name} // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
              />
            ))}

            {locationGet && (
              <MapMarker
                position={{
                  lat: locationGet.latitude,
                  lng: locationGet.longitude,
                }}
                image={{
                  src: IcCamel,
                  size: {
                    width: 24,
                    height: 35,
                  },
                }}
                title={"내 위치"}
              />
            )}
          </MarkerClusterer>
        </Map>
      ) : null}

      <Footer />
    </Container>
  );
}
