import { useEffect, useState } from "react";

type LocationType = {
  latitude: number | null;
  longitude: number | null;
};

export default function ChangeLocation() {
  const [location, setLocation] = useState<LocationType>({
    latitude: null,
    longitude: null,
  });

  const updateLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      });
    }
  };
  useEffect(() => {
    updateLocation();
    console.log("Current Location:", location);
  }, []);
  return location;
}
