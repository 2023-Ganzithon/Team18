import React, { useState, useEffect } from "react";
import styled from "styled-components";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { Link } from "react-router-dom";
import { IconArrowLeft, IconShop } from "../../assets/images/icons";
import Button from "../../components/Button";
import { theme } from "../../styles/theme";

interface CocoAmountProps {
  Coco: number;
}

interface MyItem {
  myItemId: number;
  buyDate: string;
  usePoint: number;
  itemUser: {
    userId: number;
    kakaoId: number;
    userInviteCode: string;
    password: string;
    email: string;
    userPhoneNumber: string;
    userName: string;
    userGrade: string;
    user_x: number;
    user_y: number;
    profileImageUrl: string;
  };
}

interface UserPoint {
  userPointId: number;
  userPoint: number;
  pointDate: string;
}
const CocoDataContainer = styled.div`
  padding: 10px;
  margin-bottom: 80px;
`;

const CocoList = styled.ul`
  list-style: none;
`;

const CocoItem = styled.li`
  display: flex;
  justify-content: space-between;
  gap: 30px; /* 원하는 간격으로 조정 */
  margin-bottom: 20px;
  padding: 20px;
  padding-left: 40px;
  padding-right: 40px;
  border: 1px solid #ddd;
  border-radius: 4px;
`;


const CocoDate = styled.span`
  font-weight: bold;
  color: #666;
  font-size: 1.4rem;
`;

const CocoLocation = styled.span`
  color: #666;
  font-size: 1.4rem;
`;

const CocoAmount = styled.span<CocoAmountProps>`
  color: ${(props) => (props.Coco < 0 ? 'red' : 'green')};
  font-size: 1.4rem;
`;


const CocoLogContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
`;

const CocoBlockContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  margin-top: 100px;
  width: 90%;
`;
const CocoLink = styled(Link)`
  text-decoration: none; // 링크의 밑줄을 제거합니다.
  color: inherit; // 상위 요소의 텍스트 색상을 상속받습니다.
  &:hover {
    text-decoration: underline; // 마우스 호버시 밑줄을 표시합니다.
  }
  width: 100%; // 이 부분을 100%로 수정합니다.
  display: flex; // flex 컨테이너로 만듭니다.
`;

const CocoBlock = styled.div`
  text-align: center;
  padding: 20px;
  padding-right: 0px;
  margin-bottom: 20px;
  font-size: 14px;
  color: #666;
  background: #f8f8f8;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: center;
  flex: 1;
`;

const CocoLeft = styled.div`
  text-align: center;
  padding: 25px;
  margin-bottom : 20px;
  font-size: 14px;
  color: #666;
  background: #f8f8f8;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  flex: 1; // flex 컨테이너 내에서 사용 가능한 모든 공간을 차지하도록 설정합니다.
  align-items: center;
  display: flex;
  flex-direction: column;
`;
const CocoCount = styled.div`
  margin-top: 0.5rem;
  color: green;
  font-size: 1.6rem;
  font-weight: bold;
`;

const ButtonIcon = styled.div`
   margin-left: 3rem;
`;

const ButtonContainer = styled.div`
  display: flex;
  justify-content: center;
  gap: 10px; // 버튼 사이의 간격
  margin-bottom: 20px; // 하단 여백
`;



const CoconutLog: React.FC = () => {
    const [myItems, setMyItems] = useState<MyItem[]>([]);
    const [userPoints, setUserPoints] = useState<UserPoint[]>([]);
    const [currentView, setCurrentView] = useState<'use' | 'earn'>('use');
    const userId = 0;
  
    useEffect(() => {
      fetch(`http://49.50.160.62:8080/api/getAllMyItems/${userId}`)
        .then((response) => response.json())
        .then((data) => {
          setMyItems(data);
        })
        .catch((error) => {
          console.error("Error fetching my items:", error);
        });
  
      fetch(`http://49.50.160.62:8080/api/getUserPoint/${userId}`)
        .then((response) => response.json())
        .then((data) => {
          setUserPoints(data);
        })
        .catch((error) => {
          console.error("Error fetching user points:", error);
        });
    }, [userId]);
  
    return (
      <CocoLogContainer>
        <Header />
        <CocoBlockContainer>
          <CocoLink to="/shop">
            <CocoBlock>
              <ButtonIcon style={{ margin: '0 5px 0 60px' }}>
                <IconShop />
              </ButtonIcon>
              코코넛 상점 바로가기
              <ButtonIcon style={{ margin: '0 35px' }}>
                <IconArrowLeft />
              </ButtonIcon>
            </CocoBlock>
          </CocoLink>
          <CocoLeft>
            보유한 코코넛:
            <CocoCount>{5000} 🥥</CocoCount>
          </CocoLeft>
        </CocoBlockContainer>
        <CocoDataContainer>
        <ButtonContainer>
          <Button
            onClick={() => setCurrentView('use')}
            color={theme.colors.Color_Gray_2}
            padding="10px 20px"
            borderRadius="5px"
          >
            사용 내역
          </Button>
          <Button
            onClick={() => setCurrentView('earn')}
            color={theme.colors.Color_Gray_2}
            padding="10px 20px"
            borderRadius="5px"
          >
            적립 내역
          </Button>
        </ButtonContainer>
          <h2>{currentView === 'use' ? '포인트 사용 내역' : '포인트 적립 내역'}</h2>
          <CocoList>
            {currentView === 'use'
              ? myItems.map((item, index) => (
                  <CocoItem key={index}>
                    <CocoDate>{item.buyDate.substring(0, 10)}</CocoDate>
                    <CocoLocation>상품 구매</CocoLocation>
                    <CocoAmount Coco={-item.usePoint}>
                      {-item.usePoint}🥥
                    </CocoAmount>
                  </CocoItem>
                ))
              : userPoints.map((point, index) => (
                  <CocoItem key={index}>
                    <CocoDate>{point.pointDate.substring(0, 10)}</CocoDate>
                    <CocoLocation>적립</CocoLocation>
                    <CocoAmount Coco={point.userPoint}>
                      +{point.userPoint}🥥
                    </CocoAmount>
                  </CocoItem>
                ))}
          </CocoList>
        </CocoDataContainer>
        <Footer />
      </CocoLogContainer>
    );
  };
  
  export default CoconutLog;
  