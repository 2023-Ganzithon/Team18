// import * as styles from './LoginStyle';
// import Header from '../../components/Header';
// import Button from '../../components/Button';
// import { theme } from '../../styles/theme';
// import { IconKakao } from '../../assets/images/icons';
// import Footer from '../../components/Footer';
// import { LogoLogin } from '../../assets/images/logo';

// import React, { useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import axios from 'axios';

// const Login = () => {
//   const navigate = useNavigate();

//   useEffect(() => {
//     // URL에서 'code' 파라미터를 추출합니다.
//     const urlParams = new URLSearchParams(window.location.search);
//     const code = urlParams.get('code');

//     // 콘솔에 'code' 값을 출력하여 확인합니다.
//     console.log('Extracted code:', code);

//     // 'code'가 존재하면 백엔드 API를 호출합니다.
//     if (code) {
//       axios.post('http://49.50.160.62:8080/auth/kakao/token', { code })
//         .then(response => {
//           // 성공적으로 토큰을 받으면 로컬 스토리지에 저장하고 홈페이지로 리다이렉트합니다.
//           localStorage.setItem('accessToken', response.data.access_token);
//           localStorage.setItem('refreshToken', response.data.refresh_token);
//           navigate('/');
//         })
//         .catch(error => {
//           console.error('Login failed:', error);
//           navigate('/login', { state: { error: 'Login failed. Please try again.' } });
//         });
//     }
//   }, [navigate]);

//   // 카카오 로그인 URL을 처리하는 함수
//   const handleKakaoLogin = () => {
//     window.location.href = 'https://kauth.kakao.com/oauth/authorize?client_id=bd9c7a5b1824856cb653477b896c35cc&redirect_uri=http://localhost:8080/auth/kakao/callback&response_type=code';
//   };
//   return (
//     <styles.LoginWrapper>
//       <styles.FirstSection>
//         <Header />
//       </styles.FirstSection>
//       <styles.SecondSection>
//         <styles.SecondContent>
//           <p>도시 속의 오아시스를 찾아 떠나세요 !</p>
//         </styles.SecondContent>
//         <styles.LogoImage src={LogoLogin} alt="logo-login" />
//         <styles.SpeechBubble>
//           <p>간편하게 로그인하고</p>
//           <p>수분 충전하기 💧</p>
//         </styles.SpeechBubble>
//       </styles.SecondSection>
//       <styles.ButtonSection>
//         <Button
//           color={theme.colors.Color_Gray_Black}
//           backgroundColor="#FFE812"
//           padding="1rem"
//           fontSize="1.6rem"
//           borderRadius="1rem"
//           onClick={handleKakaoLogin}
//           width="100%"
//         >
//           <styles.ButtonIcon>
//             <IconKakao />
//           </styles.ButtonIcon>
//           카카오톡으로 계속하기
//         </Button>
//       </styles.ButtonSection>
//       <Footer/>
//     </styles.LoginWrapper>
//   );
// };

// export default Login;

import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import * as styles from './LoginStyle';
import Header from '../../components/Header';
import Button from '../../components/Button';
import { theme } from '../../styles/theme';
import { IconKakao } from '../../assets/images/icons';
import Footer from '../../components/Footer';
import { LogoLogin } from '../../assets/images/logo';

const Login = () => {
  const navigate = useNavigate();
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
  
    if (code) {
      // 백엔드 서버로 요청을 보내는 대신, LoginRedirection 컴포넌트로 리다이렉트합니다.
      navigate(`/loginRedirection?code=${code}`);
    }
  }, [navigate]);
  const handleKakaoLogin = () => {
    window.location.href = 'https://kauth.kakao.com/oauth/authorize?client_id=bd9c7a5b1824856cb653477b896c35cc&redirect_uri=http://localhost:8080/auth/kakao/callback&response_type=code';
  };

  return (
    <styles.LoginWrapper>
      <styles.FirstSection>
        <Header />
      </styles.FirstSection>
      <styles.SecondSection>
        <styles.SecondContent>
          <p>도시 속의 오아시스를 찾아 떠나세요 !</p>
        </styles.SecondContent>
        <styles.LogoImage src={LogoLogin} alt="logo-login" />
        <styles.SpeechBubble>
          <p>간편하게 로그인하고</p>
          <p>수분 충전하기 💧</p>
        </styles.SpeechBubble>
      </styles.SecondSection>
      <styles.ButtonSection>
        <Button
          color={theme.colors.Color_Gray_Black}
          backgroundColor="#FFE812"
          padding="1rem"
          fontSize="1.6rem"
          borderRadius="1rem"
          onClick={handleKakaoLogin}
          width="100%"
        >
          <styles.ButtonIcon>
            <IconKakao />
          </styles.ButtonIcon>
          카카오톡으로 계속하기
        </Button>
      </styles.ButtonSection>
      <Footer/>
    </styles.LoginWrapper>
  );
};

export default Login;
