import { LayoutWrapper } from "../../components/Layout";
import { styled } from 'styled-components';
import { IconKakao } from "../../assets/images/icons";

export const LoginWrapper = styled(LayoutWrapper)`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
`;

export const ContentWrapper = styled.section`
  width: 100%;
  padding-left: 2.3rem;
  padding-right: 2.3rem;
  display: flex;
  align-items: center;
`;

export const FirstSection = styled(ContentWrapper)`
  display: flex;
  align-items: center;
  margin-top: 1rem;
  margin-bottom: 1rem;
`;

export const SecondSection = styled(ContentWrapper)`
  display: flex;
  flex-direction: column;

  margin-top: 8rem;
  margin-bottom: 1.5rem;

  gap: 5rem;
`;

export const SecondContent = styled.article`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  & > p {
    ${({ theme }) => theme.fonts.Body1_Pretendard_Medium_16};
    height: 1rem;
  }

  & > h1 {
    ${({ theme }) => theme.fonts.Noto_B_Title_3};
    font-size: 3rem;
    line-height: 131.2%;
    letter-spacing: -0.05em;
  }

  & > input {
    padding: 1.5rem;
    border-radius: 5px;
    border: 1px solid ${({ theme }) => theme.colors.Color_Gray_4};

    ${({ theme }) => theme.fonts.Body1_Pretendard_Medium_16};
  }
`;

export const ButtonSection = styled(ContentWrapper)`
  display: flex;
  align-items: center;
  margin-bottom: 30rem;
`;

export const ButtonIcon = styled(IconKakao)`
  margin-right: 8px;
`;

export const LogoImage = styled.img`
  width: 240px;
  height: auto;
`;
export const SpeechBubble = styled.div`
  position: relative;
  background: #f4f4f4; // 말풍선 배경색
  border-radius: 4px;
  padding: 1.5rem; // 여백 증가
  text-align: center;
  font-size: 1.8rem; // 텍스트 크기 증가
  width: 50%; // 말풍선의 너비를 부모 요소의 80%로 설정
  max-width: 600px; // 말풍선의 최대 너비를 600px로 설정
  margin-left: auto; // 가운데 정렬을 위해
  margin-right: auto; // 가운데 정렬을 위해

  // 말풍선 꼬리 스타일
  &::after {
    content: '';
    position: absolute;
    bottom: -30px; // 말풍선 꼬리의 위치 조정
    left: 50%;
    transform: translateX(-50%);
    border-width: 20px; // 말풍선 꼬리의 크기 조정
    border-style: solid;
    border-color: #f4f4f4 transparent transparent transparent; // 말풍선 색과 동일하게
  }
`;
