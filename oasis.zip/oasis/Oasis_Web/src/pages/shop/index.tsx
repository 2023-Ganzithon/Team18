import React, { useState, useEffect } from "react";
import styled from "styled-components";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import Modal from "../../components/Modal";

const CocoLeft = styled.div`
  text-align: center;
  padding: 25px;
  margin-top : 100px;
  margin-bottom : 20px;
  font-size: 14px;
  color: #666;
  background: #f8f8f8;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  flex: 1;
  align-items: center;
  display: flex;
  flex-direction: column;
`;

const CocoCount = styled.div`
  margin-top: 0.5rem;
  color: green;
  font-size: 1.6rem;
  font-weight: bold;
`;

const ShopContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  padding: 10px;
`;


const ItemCardContainer = styled.div`
  padding-top: 20px;
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  justify-content: center;
  padding-bottom: 80px;
`;

const ItemCard = styled.div`
  width: calc(50% - 8px);
  border: 1px solid #ccc;
  margin-bottom: 16px;
  text-align: left;
  padding: 8px;
`;

const ItemImage = styled.img`
  width: 100%;
  height: auto;
  margin-bottom: 8px;
`;

const ItemName = styled.h3`
  margin: 0;
  color: #333;
  font-size: 1.6rem; /* rem 단위를 사용하거나 px 단위로 변경 */
`;

const ItemBrand = styled.p`
  color: #666;
  font-size: 1.4rem; /* rem 단위를 사용하거나 px 단위로 변경 */
`;

const ItemPrice = styled.p`
  color: #333;
  font-size: 1.4rem; /* rem 단위를 사용하거나 px 단위로 변경 */
`;

interface Item {
  itemId: number;
  itemName: string;
  itemBrand: string | null; // itemBrand가 null일 수 있음
  itemPrice: number;
  itemImageUrl: string;
}

const Shop: React.FC = () => {
  const [items, setItems] = useState<Item[]>([]); // 상태로 아이템 목록 관리
  const [points, setPoints] = useState(5000);
  const [selectedItem, setSelectedItem] = useState<Item | null>(null);
  const [purchaseComplete, setPurchaseComplete] = useState(false);
  const [purchaseError, setPurchaseError] = useState("");

  // 백엔드에서 아이템 목록을 가져오는 함수
  useEffect(() => {
    // 백엔드 API 호출로 데이터 가져오기 (가상의 예시)
    fetch("http://49.50.160.62:8080/api/getAllItems")
      .then((response) => response.json())
      .then((data) => {
        setItems(data); // 가져온 데이터로 상태 업데이트
      })
      .catch((error) => {
        console.error("Error fetching items:", error);
      });
  }, []);

  useEffect(() => {
    const userId = 0; // 사용자 ID
    fetch(`http://49.50.160.62:8080/api/getUserPoints/${userId}`)
      .then((response) => response.json())
      .then((data) => {
          setPoints(data);
      })
      .catch((error) => {
        console.error("Error fetching user points:", error);
      });
  }, []);
  
  const handleCardClick = (item: Item) => {
    setSelectedItem(item);
    setPurchaseComplete(false);
    setPurchaseError("");
  };

  const closeModal = () => {
    setSelectedItem(null);
    setPurchaseComplete(false);
    setPurchaseError("");
  };

  const handlePurchase = () => {
    if (selectedItem && points >= selectedItem.itemPrice) {
      setPoints(points - selectedItem.itemPrice);
      console.log("Purchase successful");
      setPurchaseComplete(true);
    } else {
      console.log("Not enough points to purchase");
      setPurchaseError("구매에 실패했습니다");
    }
  };

  return (
    <ShopContainer>
      <Header />
      <CocoLeft>
        보유한 코코넛:
        <CocoCount>{points} 🥥</CocoCount>
      </CocoLeft>      
      <ItemCardContainer>
        {items.map((item) => (
          <ItemCard key={item.itemId} onClick={() => handleCardClick(item)}>
            <ItemImage src={item.itemImageUrl} alt={item.itemName} />
            <ItemName>{item.itemName}</ItemName>
            {item.itemBrand && <ItemBrand>{item.itemBrand}</ItemBrand>}
            <ItemPrice>{`${item.itemPrice.toLocaleString()}🥥`}</ItemPrice>
          </ItemCard>
        ))}
      </ItemCardContainer>
      <Footer />
      {selectedItem && (
        <Modal
          isOpen={!!selectedItem}
          onClose={closeModal}
          title={
            purchaseError ||
            (purchaseComplete ? "구매가 완료되었습니다 !" : selectedItem.itemName)
          }
          text1={
            purchaseError ? "잔여 포인트를 확인하신 후 다시 시도해주세요" : ""
          }
          text2={
            !purchaseError && !purchaseComplete
              ? `${selectedItem.itemPrice.toLocaleString()}🥥`
              : ""
          }
          action={!purchaseComplete && !purchaseError ? "구매하기" : undefined}
          onAction={
            !purchaseComplete && !purchaseError ? handlePurchase : undefined
          }
          imageUrl={selectedItem.itemImageUrl}
        />
      )}
    </ShopContainer>
  );
};

export default Shop;