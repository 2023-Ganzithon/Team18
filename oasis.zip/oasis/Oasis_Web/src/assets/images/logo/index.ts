export { ReactComponent as LogoHeader } from './LogoHeader.svg';

export { default as LogoLogin } from './LogoLogin.png';
